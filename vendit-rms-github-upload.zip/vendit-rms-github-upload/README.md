# VENDIT RMS Prototype

VENDIT RMS 가격 설정, 주변 경쟁 숙소 비교, 판매 관리 캘린더를 포함한 정적 웹 프로토타입입니다. 외부 패키지 설치 없이 실행할 수 있습니다.

## 로컬 실행

Node.js 18 이상에서 다음 명령을 실행하세요.

```sh
npm run dev
```

브라우저에서 `http://localhost:4173`을 여세요. 저장된 데모 상태 때문에 화면이 다르게 보이면 주소 끝에 `?reset=1`을 붙여 초기 상태로 다시 열 수 있습니다. 새로 열린 화면에서 **판매 관리**를 누르면 캘린더로 이동합니다.

## 확인

```sh
npm test
```

## GitHub Pages 게시

1. 이 폴더의 파일을 GitHub 저장소 루트에 올립니다.
2. 저장소의 **Settings → Pages**에서 배포 소스로 `Deploy from a branch`를 선택합니다.
3. `main` 브랜치와 `/(root)`를 선택해 저장합니다.

`index.html`이 저장소 루트에 있어야 하며, 스타일과 스크립트는 같은 위치의 파일을 불러옵니다.

## 파일 안내

- `index.html`: 화면 진입점
- `app.js`: 가격 설정, 경쟁 숙소, 판매 관리 캘린더 화면과 상호작용
- `price-stages.js`: 가격 단계 계산
- `styles.css`: 반응형 화면 스타일
- `server.mjs`: 로컬 미리보기 서버
- `tests/price-stages.test.js`: 가격 단계 계산 검증

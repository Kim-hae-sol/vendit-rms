import assert from 'node:assert/strict';
import { test } from 'node:test';

const storage = new Map([
  ['vendit-rms-prototype-v1', JSON.stringify({
    view: 'calendar',
    calendarMode: 'month',
    calendarDate: '2026-10-13',
    calendarRoomId: 'standard',
    rooms: [],
    up: [0],
    down: [0],
  })],
]);
const listeners = new Map();
globalThis.window = globalThis;
globalThis.location = { search: '', pathname: '/' };
globalThis.history = { replaceState() {} };
globalThis.localStorage = {
  getItem: (key) => storage.get(key) ?? null,
  setItem: (key, value) => storage.set(key, value),
  removeItem: (key) => storage.delete(key),
};

const app = {
  innerHTML: '',
  addEventListener(type, handler) {
    const handlers = listeners.get(type) || [];
    handlers.push(handler);
    listeners.set(type, handlers);
  },
};
globalThis.document = {
  querySelector: (selector) => selector === '#app' ? app : null,
  addEventListener() {},
};

await import('../price-stages.js');
await import('../app.js');

test('invalid empty saved room list recovers a visible calendar from prototype defaults', () => {
  assert.match(app.innerHTML, /calendar-month-grid/);
  assert.match(app.innerHTML, /스탠다드 더블/);
  assert.equal([...app.innerHTML.matchAll(/data-calendar-day=/g)].length, 31);
});

import assert from 'node:assert/strict';
import { test } from 'node:test';
import { readFile } from 'node:fs/promises';

const storage = new Map();
const listeners = new Map();
globalThis.window = globalThis;
globalThis.location = { search: '', pathname: '/' };
globalThis.history = { replaceState() {} };
globalThis.localStorage = {
  getItem: (key) => storage.get(key) ?? null,
  setItem: (key, value) => storage.set(key, value),
  removeItem: (key) => storage.delete(key),
};

const app = {
  innerHTML: '',
  addEventListener(type, handler) {
    const handlers = listeners.get(type) || [];
    handlers.push(handler);
    listeners.set(type, handlers);
  },
};
globalThis.document = {
  querySelector: (selector) => selector === '#app' ? app : null,
  addEventListener() {},
};

await import('../price-stages.js');
await import('../app.js');

test('fresh users can open the calendar and see every day in October', async () => {
  assert.match(app.innerHTML, /sidebar-progress/);

  const openCalendarTarget = {
    closest: (selector) => selector === '[data-open-calendar]' ? {} : null,
    matches: () => false,
  };
  listeners.get('click')[0]({ target: openCalendarTarget });

  assert.match(app.innerHTML, /calendar-page-heading/);
  assert.match(app.innerHTML, /calendar-month-grid/);
  assert.match(app.innerHTML, /calendar-weekday-head/);
  assert.equal([...app.innerHTML.matchAll(/data-calendar-day=/g)].length, 31);
  assert.doesNotMatch(app.innerHTML, /sidebar-progress/);
});

test('month calendar board has a nonzero base height outside fixed desktop breakpoints', async () => {
  const css = await readFile(new URL('../styles.css', import.meta.url), 'utf8');
  const baseBoardRule = css.match(/\.calendar-board\s*\{([^}]*)\}/)?.[1] || '';
  assert.match(baseBoardRule, /min-height:\s*720px/);
  assert.match(baseBoardRule, /flex:\s*1\s+1\s+720px/);
});

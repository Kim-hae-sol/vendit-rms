import assert from 'node:assert/strict';
import test from 'node:test';
import '../price-stages.js';

const { calculatePriceStageModel, calculateManualStagePrice, calculateStagePrice } = globalThis.VenditPriceStages;

function assertIntegerThousands(prices) {
  for (const price of prices) {
    assert.equal(Number.isInteger(price), true);
    assert.equal(price % 1000, 0);
  }
}

test('A: amount-based stages are evenly divided and include both bounds', () => {
  const model = calculatePriceStageModel(100000, -20, 30, 2, 5);
  assert.equal(model.valid, true);
  assert.deepEqual(model.upPrices, [130000, 115000]);
  assert.deepEqual(model.up, [30, 15]);
  assert.deepEqual(model.downPrices, [96000, 92000, 88000, 84000, 80000]);
  assert.deepEqual(model.down, [-4, -8, -12, -16, -20]);
  assertIntegerThousands([...model.upPrices, ...model.downPrices]);
});

test('B: rounded integer percentages follow the generated thousand-won amounts', () => {
  const model = calculatePriceStageModel(150000, -20, 30, 3, 3);
  assert.equal(model.valid, true);
  assert.deepEqual(model.upPrices, [195000, 180000, 165000]);
  assert.deepEqual(model.up, [30, 20, 10]);
  assert.deepEqual(model.downPrices, [140000, 130000, 120000]);
  assert.deepEqual(model.down, [-7, -13, -20]);
  assertIntegerThousands([...model.upPrices, ...model.downPrices]);
});

test('C: available step counts are bounded by the quantized limit amounts', () => {
  const model = calculatePriceStageModel(100000, -3, 2, 0, 0);
  assert.equal(model.valid, true);
  assert.equal(model.upMaxCount, 2);
  assert.equal(model.downMaxCount, 3);
  assert.equal(calculatePriceStageModel(100000, -3, 2, 3, 0).valid, false);
  assert.equal(calculatePriceStageModel(100000, -3, 2, 0, 4).valid, false);
  const full = calculatePriceStageModel(100000, -3, 2, 2, 3);
  assert.equal(full.valid, true);
  assert.deepEqual(full.upPrices, [102000, 101000]);
  assert.deepEqual(full.downPrices, [99000, 98000, 97000]);
});

test('D: recalculation after limits or counts change replaces custom amounts', () => {
  const manuallyChanged = calculatePriceStageModel(100000, -20, 30, 2, 5, {
    upPrices: [129000, 115000],
    downPrices: [96000, 92000, 88000, 84000, 80000],
  });
  assert.equal(manuallyChanged.valid, true);
  assert.deepEqual(manuallyChanged.upPrices, [129000, 115000]);

  const recalculated = calculatePriceStageModel(100000, -10, 20, 2, 2);
  assert.equal(recalculated.valid, true);
  assert.deepEqual(recalculated.upPrices, [120000, 110000]);
  assert.deepEqual(recalculated.downPrices, [95000, 90000]);
  assert.equal(recalculated.minPrice, 90000);
  assert.equal(recalculated.maxPrice, 120000);
  assert.ok(recalculated.upChartPercents.every((percent) => percent <= recalculated.max));
  assert.ok(recalculated.downChartPercents.every((percent) => percent >= recalculated.min));
});

test('manual percentage input rounds amounts toward the base and clamps to bounds', () => {
  assert.equal(calculateManualStagePrice(100000, 18, 'up', 80000, 130000), 118000);
  assert.equal(calculateManualStagePrice(100000, 55, 'up', 80000, 130000), 130000);
  assert.equal(calculateManualStagePrice(100000, -13, 'down', 80000, 130000), 87000);
  assert.equal(calculateManualStagePrice(100000, -55, 'down', 80000, 130000), 80000);
  assert.equal(calculateManualStagePrice(100000, 18.7, 'up', 80000, 130000), 118000);
  assert.equal(calculateManualStagePrice(100000, -10, 'up', 80000, 130000), 101000);
  assert.equal(calculateManualStagePrice(100000, 10, 'down', 80000, 130000), 99000);
  const updated = calculatePriceStageModel(100000, -20, 30, 2, 2, {
    upPrices: [130000, 118000],
    downPrices: [95000, 80000],
  });
  assert.equal(updated.valid, true);
  assert.deepEqual(updated.up, [30, 18]);
  assert.ok([...updated.up, ...updated.down].every(Number.isInteger));
});

test('stage amounts and chart positions remain inside both limits', () => {
  for (const model of [
    calculatePriceStageModel(100000, -20, 30, 2, 5),
    calculatePriceStageModel(150000, -20, 30, 3, 3),
    calculatePriceStageModel(100000, -3, 2, 2, 3),
  ]) {
    assert.equal(model.valid, true);
    assert.ok(model.upPrices.every((price) => price <= model.maxPrice));
    assert.ok(model.downPrices.every((price) => price >= model.minPrice));
    assert.ok(model.upChartPercents.every((percent) => percent <= model.max));
    assert.ok(model.downChartPercents.every((percent) => percent >= model.min));
    assert.ok([...model.up, ...model.down].every(Number.isInteger));
  }
});

test('existing mapping price calculation remains available', () => {
  assert.equal(calculateStagePrice(5000, -20), 4000);
  assert.equal(calculateStagePrice(5000, 15), 5750);
});

test('invalid bounds, counts, and manual amounts are rejected or constrained', () => {
  for (const args of [
    [100000, 0, 30, 2, 2],
    [100000, -20, 0, 2, 2],
    [100000, -20, -30, 2, 2],
    [100000, -20, -20, 2, 2],
    [100000, -20, 30, -1, 2],
    [100000, -20, 30, 2, 1.5],
  ]) assert.equal(calculatePriceStageModel(...args).valid, false, `${args.join(', ')}`);

  assert.equal(calculateManualStagePrice(100000, 10, 'up', 120000, 110000), null);
  const clamped = calculatePriceStageModel(100000, -20, 30, 2, 2, {
    upPrices: [150000, 50000],
    downPrices: [150000, 50000],
  });
  assert.equal(clamped.valid, true);
  assert.deepEqual(clamped.upPrices, [130000, 101000]);
  assert.deepEqual(clamped.downPrices, [99000, 80000]);
});

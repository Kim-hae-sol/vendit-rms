import assert from 'node:assert/strict';
import { test } from 'node:test';

globalThis.window = globalThis;
globalThis.location = { search: '?reset=1', pathname: '/' };
globalThis.history = { replaceState() {} };
globalThis.localStorage = {
  getItem() { throw new Error('storage unavailable'); },
  setItem() { throw new Error('storage unavailable'); },
  removeItem() { throw new Error('storage unavailable'); },
};

const app = { innerHTML: '', addEventListener() {} };
globalThis.document = {
  querySelector: (selector) => selector === '#app' ? app : null,
  addEventListener() {},
};

await import('../price-stages.js');
await import('../app.js');

test('app still renders its default setup when browser storage is unavailable', () => {
  assert.match(app.innerHTML, /객실별 기준가를 확인해 주세요/);
  assert.match(app.innerHTML, /스탠다드 더블/);
});
